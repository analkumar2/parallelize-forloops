from distutils.core import setup
setup(name='goMultiprocessing',
      version='1.0',
      description='Python Distribution Utilities',
      author='Anal Kumar',
      author_email='analkumar2@gmail.com',
      url='https://github.com/analkumar2/parallelize-forloops',
      py_modules=['goMultiprocessing'],
      )